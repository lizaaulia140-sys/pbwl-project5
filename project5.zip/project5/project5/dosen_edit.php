<?php

require_once "inc/Koneksi.php";

use Inc\Koneksi;

class DosenEdit extends Koneksi
{
    public function edit($id)
    {
        $sql = "SELECT * FROM tb_dosen WHERE dosen_id = ?";

        $stmt = $this->koneksi->prepare($sql);
        $stmt->execute([$id]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$dosen = new DosenEdit();

$id = $_GET['id'];
$data = $dosen->edit($id);

if (!$data) {
    die("Data dosen tidak ditemukan.");
}

?>

<div class="container-fluid">

    <h3 class="mb-3">Edit Data Dosen</h3>

    <form action="dosen_proses.php" method="POST">

        <input type="hidden" name="dosen_id"
            value="<?= $data['dosen_id']; ?>">

        <div class="mb-3">
            <label>NIP</label>
            <input type="text" name="dosen_nip"
                class="form-control"
                value="<?= htmlspecialchars($data['dosen_nip']); ?>"
                required>
        </div>

        <div class="mb-3">
            <label>Nama Dosen</label>
            <input type="text" name="dosen_nama"
                class="form-control"
                value="<?= htmlspecialchars($data['dosen_nama']); ?>"
                required>
        </div>

        <div class="mb-3">
            <label>Jabatan</label>
            <input type="text" name="dosen_jabatan"
                class="form-control"
                value="<?= htmlspecialchars($data['dosen_jabatan'] ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label>Golongan</label>
            <input type="text" name="dosen_golongan"
                class="form-control"
                value="<?= htmlspecialchars($data['dosen_golongan'] ?? ''); ?>">
        </div>

        <button type="submit" name="update" class="btn btn-primary">
            Update
        </button>

        <a href="index.php?page=dosen" class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>