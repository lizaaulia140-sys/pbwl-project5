<h2 class="fw-bold mb-3">Dashboard</h2>

<div class="alert alert-info" role="alert">
    Selamat datang di aplikasi akademik sederhana menggunakan PHP OOP © 2026 Liza aulia sabila (Project 5).
</div>