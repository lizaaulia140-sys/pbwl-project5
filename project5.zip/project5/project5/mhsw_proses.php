<?php

require_once "inc/Koneksi.php";
require_once "app/Mahasiswa.php";

$mhsw = new App\Mahasiswa();

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'store':
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['store'])) {
            $mhsw->store();
        }

        header("Location: index.php?page=mhsw");
        exit;

    case 'update':
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
            $mhsw->update();
        }

        header("Location: index.php?page=mhsw");
        exit;

    case 'delete':
        if (isset($_GET['id'])) {
            $mhsw->delete($_GET['id']);
        }

        header("Location: index.php?page=mhsw");
        exit;

    default:
        header("Location: index.php?page=mhsw");
        exit;
}